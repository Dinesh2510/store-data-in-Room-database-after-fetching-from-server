package com.example.myroomdatabase;

import android.content.Context;
import android.graphics.Typeface;

/*
 * Project Upload
 *
 * */

public class TypeFactory {

    private String ROBOTO_REGULAR="fonts/Roboto-Regular.ttf";
    private String ROBOTO_MEDIUM="fonts/Roboto-Medium.ttf";
    private String ROBOTO_BOLD="fonts/Roboto-Bold.ttf";

    Typeface robotoRegular,robotoMedium,robotoBold;

    public TypeFactory(Context context){

        robotoRegular = Typeface.createFromAsset(context.getAssets(),ROBOTO_REGULAR);
        robotoMedium = Typeface.createFromAsset(context.getAssets(),ROBOTO_MEDIUM);
        robotoBold = Typeface.createFromAsset(context.getAssets(),ROBOTO_BOLD);

    }


}
