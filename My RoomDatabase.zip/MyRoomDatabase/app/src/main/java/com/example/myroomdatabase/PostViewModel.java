package com.example.myroomdatabase;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class PostViewModel extends AndroidViewModel {

    PostRepository nurseRepository;
    LiveData<List<PostData>> nurseList;
    PostData nurseData;


    public PostViewModel(@NonNull Application application) {
        super(application);
        nurseRepository = new PostRepository(application);
    }


    public void insert(PostData nurseData) {
        nurseRepository.insert(nurseData);
    }

    public void update(PostData nurseData) {
        nurseRepository.update(nurseData);
    }

    public void delete(PostData nurseData) {
        nurseRepository.delete(nurseData);
    }

    public void deleteAllNurse() {
        nurseRepository.DeleteAllNurseData();
    }

    public LiveData<List<PostData>> GetAllNurseList() {
        return nurseRepository.getAllNurseData();
    }



    public void DeleteDataWithUniqueid(String unique_id){
        nurseRepository.DeleteDataWithUniqueid(unique_id);
    }

    public PostData GetUserIdBasedData(String user_id){
        nurseData = nurseRepository.GetUserIdBasedData(user_id);
        return nurseData;
    }

    public void DeleteAllNurseData(){
        nurseRepository.DeleteAllNurseData();
    }
    public List<PostData> GetFilterData(String degree,String home_visit, String area){

        return nurseRepository.GetFilterData(degree,home_visit,area);
    }


    public void DeleteUserBaseDataAsyncTask(String user_id){
        nurseRepository.DeleteUserBaseData(user_id);
    }


}