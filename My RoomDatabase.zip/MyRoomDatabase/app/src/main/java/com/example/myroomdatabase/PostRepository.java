package com.example.myroomdatabase;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class PostRepository {
    public PostDao nurseDAO;
    LiveData<List<PostData>> nurseList;
    PostData nurseData;

    public PostRepository(Application application) {
        ProjectDatabase database = ProjectDatabase.getDatabaseInstance(application);
        nurseDAO = database.nurseDAO();
    }


    public void insert(PostData nurseData) {
        new PostRepository.InsertNurseAsyncTask(nurseDAO).execute(nurseData);
    }

    public void update(PostData nurseData) {
        new PostRepository.UpdateNurseAsyncTask(nurseDAO).execute(nurseData);
    }

    public void delete(PostData nurseData) {
        new PostRepository.DeleteNurseAsyncTask(nurseDAO).execute(nurseData);

    }


    public LiveData<List<PostData>> getAllNurseData() {

        return nurseDAO.getAllNurseData();
    }


    public List<PostData> GetFilterData(String degree, String home_visit, String area) {
        List<PostData> data = null;
        try {
            data = new PostRepository.GetFilterDataAsyncTask(nurseDAO).execute(degree, home_visit, area).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }

        return data;
    }


    public void DeleteAllNurseData() {

        new PostRepository.DeleteAllNurseDataAsyncTask(nurseDAO).execute();
    }


    public PostData GetUserIdBasedData(String user_id) {
        try {
            nurseData = new PostRepository.GetUserIdBasedDataAsyncTask(nurseDAO).execute(user_id).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }

        return nurseData;
    }


    public void DeleteDataWithUniqueid(String unique_id) {
        new PostRepository.DeleteWithUniqueidAsyncTask(nurseDAO).execute(unique_id);
    }

    public void DeleteUserBaseData(String user_id) {
        new DeleteUserBaseDataAsyncTask(nurseDAO).execute(user_id);
    }

    public static class DeleteUserBaseDataAsyncTask extends AsyncTask<String, Void, Void> {

        PostDao nurseDAO;

        public DeleteUserBaseDataAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected Void doInBackground(String... strings) {
            nurseDAO.DeleteUserBaseData(strings[0]);
            return null;
        }
    }

    public static class InsertNurseAsyncTask extends AsyncTask<PostData, Void, Void> {
        PostDao nurseDAO;

        public InsertNurseAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected Void doInBackground(PostData... nurs) {
            nurseDAO.insert(nurs[0]);
            return null;
        }
    }

    public class UpdateNurseAsyncTask extends AsyncTask<PostData, Void, Void> {
        PostDao nurseDAO;

        public UpdateNurseAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected Void doInBackground(PostData... nurs) {
            nurseDAO.update(nurs[0]);
            return null;
        }
    }

    public static class DeleteNurseAsyncTask extends AsyncTask<PostData, Void, Void> {
        PostDao nurseDAO;

        public DeleteNurseAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected Void doInBackground(PostData... nurs) {

            nurseDAO.delete(nurs[0]);

            return null;
        }
    }

    public class DeleteAllNurseDataAsyncTask extends AsyncTask<Void, Void, Void> {

        PostDao nurseDAO;

        public DeleteAllNurseDataAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;

        }

        @Override
        protected Void doInBackground(Void... Void) {

            nurseDAO.DeleteAllNurseData();
            return null;
        }


    }


    public class GetUserIdBasedDataAsyncTask extends AsyncTask<String, Void, PostData> {

        PostDao nurseDAO;

        GetUserIdBasedDataAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected PostData doInBackground(String... strings) {
            return nurseDAO.GetUserIdBasedNurseData(strings[0]);
        }

        @Override
        protected void onPostExecute(PostData nurseData) {
            super.onPostExecute(nurseData);
        }
    }


    public class GetFilterDataAsyncTask extends AsyncTask<String, Void, List<PostData>> {
        PostDao nurseDAO;

        GetFilterDataAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected List<PostData> doInBackground(String... strings) {

            String degree = strings[0];
            String home_visit = strings[1];
            String area = strings[2];


            return nurseDAO.GetFilterData(degree, home_visit, area);
        }

        @Override
        protected void onPostExecute(List<PostData> nurseData) {
            super.onPostExecute(nurseData);
        }
    }


    private class DeleteWithUniqueidAsyncTask extends AsyncTask<String, Void, Void> {

        PostDao nurseDAO;

        DeleteWithUniqueidAsyncTask(PostDao nurseDAO) {
            this.nurseDAO = nurseDAO;
        }

        @Override
        protected Void doInBackground(String... strings) {
            nurseDAO.DeleteNurseData(strings[0]);
            return null;
        }
    }


}
