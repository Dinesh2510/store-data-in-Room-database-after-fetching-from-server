package com.example.myroomdatabase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PostDao {

    @Insert
    public void insert(PostData nurseData);

    @Update
    public void update(PostData nurseData);

    @Delete
    public void delete(PostData nurseData);

    @Query("DELETE FROM post_data")
    public void DeleteAllNurseData();

    @Query("SELECT * FROM post_data ")
    public LiveData<List<PostData>> getAllNurseData();

    @Query("SELECT * FROM post_data WHERE post_title =:area ")
    public List<PostData> getAllNurseDataList(String area);

    @Query("DELETE FROM post_data WHERE post_id = :post_id")
    public void DeleteNurseData(String post_id);


    @Query("SELECT * FROM post_data WHERE post_id = :post_id")
    public PostData GetNurseData(String post_id);



    @Query("SELECT * FROM post_data WHERE post_id = :post_id")
    public PostData GetUserIdBasedNurseData(String post_id);


    @Query("UPDATE post_data SET post_content=1 WHERE post_id = :post_id")
    void UpdateAllNurseData(String post_id);




     /*@Query("SELECT * FROM post_data WHERE (degree LIKE :degree AND nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer AND home_visit LIKE :home_visit AND cpr LIKE:cpr)" +
            " OR (degree LIKE :degree AND nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer AND home_visit LIKE:home_visit) " +
            " OR (degree LIKE :degree AND nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer AND cpr LIKE:cpr ) " +
            " OR (degree LIKE :degree AND home_visit LIKE :home_visit AND cpr LIKE:cpr) " +
            "OR (nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer AND home_visit LIKE:home_visit AND cpr LIKE:cpr) " +
            "OR (degree LIKE :degree AND nurse_register_as_medical_volunteer LIKE:nurse_register_as_medical_volunteer ) " +
            "OR (degree LIKE :degree AND home_visit LIKE:home_visit ) " +
            "OR (degree LIKE :degree AND cpr LIKE:cpr ) " +
            "OR (nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer AND home_visit LIKE:home_visit ) " +
            "OR (nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer AND cpr LIKE:cpr ) " +
            "OR (home_visit LIKE :home_visit AND cpr LIKE:cpr ) " +
            "OR (degree LIKE :degree ) " +
            "OR (nurse_register_as_medical_volunteer LIKE :nurse_register_as_medical_volunteer ) " +
            "OR (home_visit LIKE :home_visit ) " +
            "OR (cpr LIKE:cpr)")*/

    @Query("SELECT * FROM post_data WHERE (post_title LIKE :post_title AND post_content LIKE :post_content AND post_link LIKE:post_link)" )
    public List<PostData> GetFilterData(String post_title,String post_content, String post_link);


    @Query("DELETE FROM post_data WHERE post_id = :post_id")
    public void DeleteUserBaseData(String post_id);

}
