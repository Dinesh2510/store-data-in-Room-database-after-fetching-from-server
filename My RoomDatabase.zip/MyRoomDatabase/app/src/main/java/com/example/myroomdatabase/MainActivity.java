package com.example.myroomdatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    PostViewModel nurseViewModel;
    TextView search_bar;
    List<PostData> nurselist = new ArrayList<>();
    PostAdapter adapter;
    RecyclerView NurseRecyclerView;
    String user_id;
    String str_area_city;
    Toolbar toolbar;
    public static final String NURSE_USER_ID = "nurse_user_id";
    SharedPreferences sharedPreferences;
    String str_user_id, str_near_by;
    TextView near_by, tv_empty;
    private final int MASTER_SEARCH_REQUEST = 101;
    ImageView filter;
    TextView toolbar_title;
    String app_language;
    String title_nurselList;
    String tag = "list_new";
    Bundle filterBundle = null;
    SwipeRefreshLayout swipe_refresh = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);

        initViews();
        setRecyclerView();
        setAdapters();
        setViewModels();
        setonClickListeners();
        //GetNurseList();

    }


    private void setEmptyLayout(int size) {
        if (size == 0) {
            tv_empty.setText("No nurse found for your search");
            tv_empty.setVisibility(View.VISIBLE);
            NurseRecyclerView.setVisibility(View.GONE);
        } else {
            tv_empty.setVisibility(View.GONE);
            NurseRecyclerView.setVisibility(View.VISIBLE);
        }
    }


    private void initViews() {

        toolbar_title = findViewById(R.id.tv_title);
        tv_empty = findViewById(R.id.tv_empty);
        tv_empty.setText("No nurse found for your search");

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        search_bar = findViewById(R.id.search_bar);
        near_by = findViewById(R.id.near_by);
        NurseRecyclerView = findViewById(R.id.NurseRecyclerView);
        filter = findViewById(R.id.filter);
        swipe_refresh = findViewById(R.id.swipe_refresh);
    }


    private void setRecyclerView() {
        NurseRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        NurseRecyclerView.setHasFixedSize(true);
    }


    private void setAdapters() {
        adapter = new PostAdapter();
        NurseRecyclerView.setAdapter(adapter);
    }


    private void setViewModels() {
        nurseViewModel = ViewModelProviders.of(this).get(PostViewModel.class);
        nurseViewModel.GetAllNurseList().observe(this, new Observer<List<PostData>>() {
            @Override
            public void onChanged(List<PostData> nurse) {

                nurselist = nurse;
                adapter.submitList(nurse);
                setEmptyLayout(nurse.size());
            }
        });
    }


    private void setonClickListeners() {

        swipe_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                tv_empty.setText("Loading...");
                GetNurseList();
            }
        });


        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "hello", Toast.LENGTH_SHORT).show();

            }
        });


        search_bar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filter(editable.toString());
            }
        });


    }


    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<PostData> filterdList = new ArrayList<>();

        for (PostData nurse : nurselist) {

            String nurse_name = nurse.getPost_title();
            String nurse_address = nurse.getPost_content();
            if (nurse_name.toLowerCase().contains(text.toLowerCase()) || nurse_address.toLowerCase().contains(text.toLowerCase())) {

                filterdList.add(nurse);
            }
        }

        //calling a method of the adapter class and passing the filtered list
        adapter.submitList(filterdList);
        setEmptyLayout(filterdList.size());

    }


    public void GetNurseList() {
        String url = "https://pixeldev.in/webservices/digital_reader/GetAllPostList.php";
        String tag_json_obj = "json_obj_req";

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    String serverResponse = object.getString("response");
                    Log.d("NURSE_RESPONSE", "" + response);

                    if (!serverResponse.equalsIgnoreCase("failure")) {

                        JSONArray listData = object.getJSONArray("response");

                        nurseViewModel.deleteAllNurse();

                        JSONArray jsonArray = new JSONArray(serverResponse);

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObject = jsonArray.getJSONObject(i);

                            String post_id = dataObject.getString("post_id");

                            String post_title = dataObject.getString("post_title");
                            String post_sub_title = dataObject.getString("post_sub_title");
                            String post_content = dataObject.getString("post_content");
                            String post_userid = dataObject.getString("post_userid");
                            String post_username = dataObject.getString("post_username");
                            String post_image = dataObject.getString("post_image");
                            String post_date = dataObject.getString("post_date");
                            String post_link = dataObject.getString("post_link");
                            String topics = dataObject.getString("topics");
                            String post_view = dataObject.getString("post_view");
                            String post_like = dataObject.getString("post_like");
                            String premium_flag = dataObject.getString("premium_flag");


                            PostData data = new PostData(post_id, post_title, post_sub_title, post_content, post_userid,
                                    post_username, post_date, post_image, post_link, topics, post_view, post_like, premium_flag);
                            nurseViewModel.insert(data);


                        }

                    }
                    handleSwipeRefresh();
                } catch (JSONException e) {
                    handleSwipeRefresh();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleSwipeRefresh();
            }
        });
        AppController.getInstance().addToRequestQueue(request, tag_json_obj);
    }

    private void handleSwipeRefresh() {
        if (swipe_refresh.isRefreshing()) {
            swipe_refresh.setRefreshing(false);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MASTER_SEARCH_REQUEST && resultCode == RESULT_OK) {

            Bundle bundle = new Bundle();
            bundle = data.getBundleExtra("intentdata");
            filterBundle = bundle;
            if (bundle != null) {


                String nurse_degree = bundle.getString("nurse_degree");
                String home_visit = bundle.getString("home_visit");
                String area = bundle.getString("area");

                try {

                    nurse_degree = "%" + nurse_degree + "%";
                    home_visit = "%" + home_visit + "%";
                    area = "%" + area + "%";

                    nurselist = nurseViewModel.GetFilterData(nurse_degree, home_visit, area);
                    adapter.submitList(nurselist);

                    setEmptyLayout(nurselist.size());
                } catch (Exception ignored) {

                }


            }
        }
    }
}
//nurse list